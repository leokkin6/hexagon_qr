                <!-- General Scripts -->
<!-- Required Jqurey -->
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/tether/dist/js/tether.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?> "></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>
<!-- modernizr js -->
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/modernizr/modernizr.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/modernizr/feature-detects/css-scrollbars.js')); ?>"></script>
<!-- classie js -->
<script type="text/javascript" src="<?php echo e(URL::asset('bower_components/classie/classie.js')); ?>"></script>
<!-- Custom js -->
<script type="text/javascript" src="<?php echo e(URL::asset('assets/pages/dashboard/custom-dashboard.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/script.js')); ?>"></script>
                <!-- End of General Scripts -->






