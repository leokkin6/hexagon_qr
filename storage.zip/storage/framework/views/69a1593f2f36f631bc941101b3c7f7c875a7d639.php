 
<?php $__env->startSection('title','| User Registration'); ?>
<?php $__env->startSection('content_header','User Registration'); ?>
<?php $__env->startSection('content_subheader','User registration for QR Access'); ?>
<?php $__env->startSection('breadcrumb', 'User Registration'); ?>

 
<?php $__env->startSection('content'); ?>
<!--General Information Card-->
<div class="card">
    <div class="card-block">
        <!-- Tab panes -->
        <div class="row">
            <div class="col-xs-9 col-md-7">
                <!-- Header LSection -->
                <h4 class="sub-title"><i class="icofont icofont-ui-user"></i></i> General Information</h4>
                <!-- Information Forms -->
                <?php echo Form::open(['route' => 'registration.store']); ?>

                <div class="row">
                    <div class="form-group col-sm-9">
                        <?php echo e(Form::label('EmployeeID', 'Employee ID:')); ?>

                        <?php echo e(Form::text('EmployeeID', null, array('class' => 'form-control', 'placeholder'=>'Employee ID', 'id'=>'txt_employeeID','required'=>''))); ?>

                    </div>
                    <div class="form-group col-sm-3">
                        <?php echo e(Form::label('SystemUser', 'System User:')); ?>

                        <?php echo e(Form::select('SystemUser', ['0' => 'No','1' => 'Yes'],null,['class' => 'form-control'])); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('LastName', 'Last Name:')); ?>

                    <?php echo e(Form::text('LastName', null, array('class' => 'form-control', 'placeholder'=>'Last Name', 'id'=>'txt_LastName' ,'required'=>''))); ?>

                </div>
                <div class="row">
                    <div class="form-group col">
                        <?php echo e(Form::label('Title', 'Title:')); ?> 
                        <?php echo e(Form::select('Title', ['M' => 'Mister','Ms' => 'Miss'],null,['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group col">
                        <?php echo e(Form::label('FirstName', 'First Name:')); ?> 
                        <?php echo e(Form::text('FirstName', null, array('class'=>'form-control', 'placeholder'=>'First Name', 'required'=>''))); ?>

                    </div>
                    <div class="form-group col">
                        <?php echo e(Form::label('MiddleName', 'Middle Name:')); ?>

                        <?php echo e(Form::text('MiddleName', null, array('class' => 'form-control', 'placeholder'=>'Middle Name', 'required'=>''))); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <?php echo e(Form::label('Department', 'Deparment')); ?> 
                        <?php echo e(Form::text('Deparment', null, array('class'=>'form-control', 'placeholder'=>'Deparment', 'id'=>'txt_Department', 'required'=>''))); ?>

                    </div>
                    <div class="form-group col">
                        <?php echo e(Form::label('Unit', 'Unit')); ?> 
                        <?php echo e(Form::text('Unit', null, array('class'=>'form-control', 'placeholder'=>'Unit', 'required'=>''))); ?>

                    </div>
                    <div class="form-group col">
                        <?php echo e(Form::label('Division', 'Division')); ?> 
                        <?php echo e(Form::text('Division', null, array('class'=>'form-control', 'placeholder'=>'Division', 'required'=>''))); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Position', 'Position:')); ?>

                    <?php echo e(Form::text('Position', null, array('class' => 'form-control', 'placeholder'=>'Position', 'required'=>''))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Email', 'E-mail Address:')); ?>

                    <?php echo e(Form::email('Email', null, array('class' => 'form-control', 'placeholder'=>'E-mail Address', 'required'=>'','data-parsley-type'=>'email'))); ?>

                </div>
                <?php echo e(Form::submit('Submit',array('class'=>'pull-right btn btn-primary col'))); ?>   
                <!-- End of Information Forms -->
            </div>
            <!-- Header RSection -->
            <div class="col-xs-3 col-md-5">
                <div class="form-group">
                    <h4 class="sub-title"><i class="icofont icofont-id-card"></i> Identification Photo</h4>
                    <!-- Profile Card -->
                    <div class="col">
                        <div class="card rounded-card user-card">
                            <div class="card-block">
                                <div class="img-hover">
                                    <img class="img-fluid img-circle" src="<?php echo e(URL::asset('assets/images/avatar.png')); ?>" alt="round-img">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col">
                        <input type="file" class="form-control">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--QR Authentication-->
<div class="card">
    <div class="card-block">
        <!-- Tab panes -->
        <div class="row">
            <div class="col-xs-9 col-md-7">
                <!-- Header LSection -->
                <h4 class="sub-title"><i class="icofont icofont-lock"></i> QR Authentication</h4>
                <!-- Information Forms -->
                <div class="form-group">
                    <?php echo e(Form::label('QRValue', 'QR Value:')); ?>

                    <?php echo e(Form::text('QRValue', null, array('class' => 'form-control', 'id'=>'txt_QRValue', 'readonly'))); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('HashedValue', 'Hashed Value:')); ?>

                    <?php echo e(Form::text('HashedValue', null, array('class' => 'form-control', 'readonly','id'=>'txt_QRHash'))); ?>

                </div>  
                <?php echo Form::close(); ?>

                <!-- End of Information Forms -->
            </div>
            <!-- Header RSection -->
            <div class="form-group col">
                <h4 class="sub-title"><i class="icofont icofont-id-card"></i>QR Image</h4>
                <!-- Profile Card -->
                <div class="card user-card">
                    <div class="card-block">
                        <div class="img-hover" id="QRresult"> 
                            <center><img class="img-fluid" src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=9e2256c95f8f0d7db5709ab27a778b9f" alt=""></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_page_script'); ?>

<?php echo Html::script('js/parsley.min.js'); ?>


 
<script type="text/javascript">
    $(document).ready(function () {
     $('#txt_employeeID,#txt_LastName,#txt_Department').keyup(function() {
        var qrvalue = $('#txt_QRValue').val();
        var hashed_value = generate_qrcode(qrvalue);
            
            $('#txt_QRValue').val($('#txt_employeeID').val()+'-'+$('#txt_LastName').val()+'-'+$('#txt_Department').val());
            $('#txt_QRHash').val(hashed_value);
        });
    });

    function generate_qrcode(qrValue){
        $.ajax({
            type: 'get',
            url: '/qr/generator/getQRValueReg',
            data: {qrValue:qrValue},
            success: function(data){
                $('#QRresult').html(data.code);
                $('#txt_QRHash').val(data.codeHash);
            }
        });
    }
 
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>