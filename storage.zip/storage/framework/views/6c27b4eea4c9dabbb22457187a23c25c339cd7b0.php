<?php $__env->startSection('has_class','has class'); ?>
<?php $__env->startSection('title','| QR GENERATOR'); ?>
<?php $__env->startSection('content_header','QR Generator'); ?>
<?php $__env->startSection('content_subheader','Generate QR for registered employee'); ?>
<?php $__env->startSection('breadcrumb','QR Generator'); ?>


<?php $__env->startSection('content'); ?>
<!--QR Card -->
<div class="card">
    <div class="card-block">
        <!-- Tab panes -->
        <?php echo Form::open(['route' => 'registration.store']); ?>

        <div class="row">
            <div class="col-xs-9 col-md-7">
                <!-- Header LSection -->
                <h4 class="sub-title"><i class="icofont icofont-lock"></i> Customize QR Generator</h4>
                <!-- Information Forms -->
                <div class="form-group">
                    <?php echo e(Form::textarea('QRValue', null, array('class' => 'form-control','onkeyup'=>'generate_qrcode(this.value)', 'id'=>'QRValue', 'placeholder'=>'Input QR value here...'))); ?>

                </div>
                
                <!-- End of Information Forms -->
            </div>
            <!-- Header RSection -->
            <div class="form-group col">
                <h4 class="sub-title"><i class="icofont icofont-id-card"></i>QR Image</h4>
                <!-- Profile Card -->
                <div class="card user-card">
                    <div class="card-block">
                        <div class="img-hover" id="QRresult">
                            <center><img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=applychange" title="Link to Google.com"></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>

		
        <?php echo Form::close(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_page_script'); ?>

<script type="text/javascript">

	function generate_qrcode(qrValue){
		$.ajax({
			type: 'get',
			url: '/qr/generator/getQRValueGen',
			data: {qrValue:qrValue},
			success: function(code){
				$('#QRresult').html(code);
			}
		});
	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>