<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('custom_page_style'); ?>
    </head>
    
<body class="horizontal-icon-fixed">

    <?php echo $__env->make('partials._nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main-body start-->
    <?php echo $__env->make('partials._contentHeader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Main content -->
            <?php echo $__env->yieldContent('content'); ?>
        <!-- Main-body end-->

    <?php echo $__env->make('partials._warnings', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials._javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('custom_page_script'); ?>

</body>

</html>
